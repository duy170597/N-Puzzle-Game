/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package puzzlegameview;

/**
 *
 * @author duy
 */
public class Fringe {
    public static Node[] number = new Node[362880];    // luu cac trag thai
    public static int count;   // dem so luong cac trang thai
    
    // khoi tao hang doi rong
    public Fringe() {
       count = 0;
    }
    
    // Kiem tra hang doi rong
    public boolean isEmpty() {
        if(count == 0)  return true;
        return false;
    }
    // kiem tra Fringe day
    public boolean isFull() {
        if(count == 362800)  return true;
        return false;
    }
    
    // Them mot trang thai vao fringe
    public boolean push(Node N) {
        if(!isFull()) {
            number[count] = N;
            count++;
            return true;
        }
        return false;
    }
    
    // Xoa mot trang thai
    public Node pop() {
        if(isEmpty()) {
            System.out.println("Fringe rong!");
            return null;
        }
        else {
            int i, j=0;
            // Tim fringe min
            Node fMin = number[0];
            for(i = 0; i < count; i++) {
                if(number[i].getF() < fMin.getF()) {
                    fMin = number[i];
                    j = i;  // luu lai vi tri status co f min
                }
            }
            for(i = j; i < count-1; i++) {
                number[i] = number[i+1];
            }
            count--;
            return fMin;
        }
    }
}


