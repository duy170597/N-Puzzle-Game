
package puzzlegameview;

import java.util.Arrays;


public class AStarH3 {
    long start, finish, time;
    int soNutTaoRa, soNutPhaiXet, soNutTrenCay;
  
    public Node runAStar(Node begin, Node end, Fringe F, ListStatus LS) {
        //luu y: truoc khi chay A* can gan g = 0, f = 0
        begin.setH(0); begin.setG(0);   begin.setF(0);
        start = System.currentTimeMillis();
        soNutTaoRa = 0;
        soNutPhaiXet = 0;
        soNutTrenCay = 1;
        int i, j, result;
        // nap begin vao fringe
        F.push(begin);
        Node p; // nut cha
        while(F.isEmpty() == false) {
            p = F.pop();    soNutPhaiXet++;
            if(Arrays.equals(p.getStatus(), end.getStatus())) {
                finish = System.currentTimeMillis();
                time = finish - start;
                ListStatus.count = 0;   // Khoi tao lai trang thai ban dau
                Fringe.count = 0;       // Khoi tao lai trang thai ban dau
                
                return p;
            }
            else {
                LS.nextStatus(p);
                for(i = 0; i < ListStatus.count; i++) {
                    // tinh f = g + h;
                    ListStatus.number[i].setG(p.getG()+1);
                    ListStatus.number[i].setH(ListStatus.number[i].heuristic3(end.getStatus()));
                    ListStatus.number[i].setF(ListStatus.number[i].getH() + ListStatus.number[i].getG());
                    ListStatus.number[i].setParent(p);
                    
                    // kiem tra vao push cac trang thai vao fringe
                    if(p.getParent() != null) {
                        // neu trang thai dang xet khong trung vs cha cua trang thai p
                        if(!Arrays.equals(ListStatus.number[i].getStatus(), p.getParent().getStatus())) {
                            result = 0;
                    //System.out.println(ListStatus.number[i].getF());
                    //ListStatus.number[i].printStatus();
                            for(j = 0; j < Fringe.count; j++) {
                                if(Arrays.equals(ListStatus.number[i].getStatus(), Fringe.number[j].getStatus())) {
                                    result = 1;
                                    break;
                                }
                            }
                            if(result == 0) {
                                soNutTrenCay++;
                                if(!F.push(ListStatus.number[i])) {
                                    System.out.println("Da vuot qua bo nho cua Fringe!");
                                    ListStatus.count = 0;   // Khoi tao lai trang thai ban dau
                                    Fringe.count = 0;       // Khoi tao lai trang thai ban dau
                                    return null;
                                }
                            }
                        } 
                    }
                    else {        
                        soNutTrenCay++;
                        if(!F.push(ListStatus.number[i])) {
                            System.out.println("Da vuot qua bo nho cua Fringe!");
                            ListStatus.count = 0;   // Khoi tao lai trang thai ban dau
                            Fringe.count = 0;       // Khoi tao lai trang thai ban dau
                            return null;
                        }
                    }
                    soNutTaoRa++;
                }
                ListStatus.count = 0;
            }
        }
        finish = System.currentTimeMillis();
        ListStatus.count = 0;   // Khoi tao lai trang thai ban dau
        Fringe.count = 0;       // Khoi tao lai trang thai ban dau
        return null;
    }
    
    public void result(Node end) {
       Node p = end;
       while(p.getParent() != null) {   // tim nodeBegin
           p.getParent().setChild(p);
           p = p.getParent();       // noi thanh cac node 
       }
       while(p != null) {
           System.out.printf("f = %d, g = %d, h = %d\n", p.getF(), p.getG(), p.getH());
           p.printStatus();
           p = p.getChild();
       }
   }
}
