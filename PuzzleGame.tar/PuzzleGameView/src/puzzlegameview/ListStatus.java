/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package puzzlegameview;

/**
 *
 * @author duy
 */
public class ListStatus {
    public static Node[] number = new Node[4];
    public static int count;
    private int n;
    // Khoi tao 
    public ListStatus(int n) {
        this.n = n;
        count = 0;
    }
    
    // danh sach cac trang thai tiep theo cua n(i)
    public void nextStatus(Node N) {
        if(N.moveUp()) {    // neu o trong di chuyen len dc thi...
            number[count] = new Node(n);
            number[count].setStatus(N.getStatus()); // sao chep trang thai hien tai cua nut cha
            number[count].setParent(N);
            count++;
            N.moveDown();   // di chuyen o trong ve cho cu
        }
        if(N.moveDown()) {    // neu o trong di chuyen len dc thi...
            number[count] = new Node(n);
            number[count].setStatus(N.getStatus()); // sao chep trang thai hien tai cua nut cha
            number[count].setParent(N);
            count++;          
            N.moveUp();   // di chuyen o trong ve cho cu
        }
        if(N.moveLeft()) {    // neu o trong di chuyen len dc thi...
            number[count] = new Node(n);
            number[count].setStatus(N.getStatus()); // sao chep trang thai hien tai cua nut cha
            number[count].setParent(N);
            count++;
            N.moveRight();   // di chuyen o trong ve cho cu
        }
        if(N.moveRight()) {    // neu o trong di chuyen len dc thi...
            number[count] = new Node(n);
            number[count].setStatus(N.getStatus()); // sao chep trang thai hien tai cua nut cha
            number[count].setParent(N);
            count++;
            N.moveLeft();   // di chuyen o trong ve cho cu
        }
    }
}
