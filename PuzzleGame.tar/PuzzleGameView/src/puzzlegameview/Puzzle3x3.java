
package puzzlegameview;

import java.util.Arrays;
import javax.swing.JOptionPane;

public class Puzzle3x3 extends javax.swing.JFrame {

    public Puzzle3x3() {
        nodeBegin.setStatus(statusBegin);
        nodeEnd.setStatus(statusEnd);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        runHeuristic1Button = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        viewTextArea = new javax.swing.JTextArea();
        goalStatusLabel = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        currentStatusLabel = new javax.swing.JLabel();
        b0 = new javax.swing.JButton();
        b3 = new javax.swing.JButton();
        b2 = new javax.swing.JButton();
        b1 = new javax.swing.JButton();
        b5 = new javax.swing.JButton();
        b4 = new javax.swing.JButton();
        b6 = new javax.swing.JButton();
        b8 = new javax.swing.JButton();
        b7 = new javax.swing.JButton();
        runHeuristic0Button = new javax.swing.JButton();
        runHeuristic2Button = new javax.swing.JButton();
        nextButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        newButton = new javax.swing.JButton();
        runHeuristic4Button = new javax.swing.JButton();
        runHeuristic3Button = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Puzzle Game");
        setAutoRequestFocus(false);
        setLocation(new java.awt.Point(0, 0));

        runHeuristic1Button.setText("Run A* (heuristic1)");
        runHeuristic1Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runHeuristic1ButtonActionPerformed(evt);
            }
        });

        viewTextArea.setColumns(20);
        viewTextArea.setRows(5);
        jScrollPane1.setViewportView(viewTextArea);

        goalStatusLabel.setText("Goal Status");

        jButton2.setText("1");

        jButton3.setText("6");

        jButton4.setText("3");

        jButton5.setText("5");

        jButton6.setText("2");

        jButton7.setText("8");

        jButton8.setText("7");

        jButton9.setText("4");

        currentStatusLabel.setText("Current Status");

        b0.setText(" ");
        b0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b0ActionPerformed(evt);
            }
        });

        b3.setText(" ");
        b3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b3ActionPerformed(evt);
            }
        });

        b2.setText(" ");
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });

        b1.setText(" ");
        b1.setOpaque(true);
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });

        b5.setText(" ");
        b5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b5ActionPerformed(evt);
            }
        });

        b4.setText(" ");
        b4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b4ActionPerformed(evt);
            }
        });

        b6.setText(" ");
        b6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b6ActionPerformed(evt);
            }
        });

        b8.setText(" ");
        b8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b8ActionPerformed(evt);
            }
        });

        b7.setText(" ");
        b7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b7ActionPerformed(evt);
            }
        });

        runHeuristic0Button.setText("Run A* (heuristic0)");
        runHeuristic0Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runHeuristic0ButtonActionPerformed(evt);
            }
        });

        runHeuristic2Button.setText("Run A* (heuristic2)");
        runHeuristic2Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runHeuristic2ButtonActionPerformed(evt);
            }
        });

        nextButton.setText("Next");
        nextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });

        exitButton.setText("Exit");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });

        newButton.setText("New");
        newButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newButtonActionPerformed(evt);
            }
        });

        runHeuristic4Button.setText("Run A* (heuristic4)");
        runHeuristic4Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runHeuristic4ButtonActionPerformed(evt);
            }
        });

        runHeuristic3Button.setText("Run A* (heuristic3)");
        runHeuristic3Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runHeuristic3ButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(runHeuristic4Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(goalStatusLabel)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(runHeuristic0Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(runHeuristic1Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(runHeuristic2Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(runHeuristic3Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(currentStatusLabel)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(newButton)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(nextButton)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(exitButton))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(b0, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(b1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(b7, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(b8, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(currentStatusLabel)
                    .addComponent(goalStatusLabel)
                    .addComponent(nextButton)
                    .addComponent(exitButton)
                    .addComponent(newButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b0, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b7, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b8, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(runHeuristic0Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(runHeuristic1Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(runHeuristic2Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(runHeuristic3Button)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(runHeuristic4Button)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b0ActionPerformed
        String s=b0.getText();  
        if(b1.getText().equals(" ")){ b1.setText(s); b0.setText(" "); nodeBegin.moveLeft();}  
        else if(b3.getText().equals(" ")){ b3.setText(s); b0.setText(" "); nodeBegin.moveUp();}
        if(Arrays.equals(nodeBegin.getStatus(), nodeEnd.getStatus()))
            JOptionPane.showMessageDialog(rootPane, "DONE!");
        nodeBegin.setChild(null);
    }//GEN-LAST:event_b0ActionPerformed

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
        String s=b1.getText();  
        if(b0.getText().equals(" ")){ b0.setText(s); b1.setText(" "); nodeBegin.moveRight();}  
        else if(b2.getText().equals(" ")){ b2.setText(s); b1.setText(" "); nodeBegin.moveLeft();}
        else if(b4.getText().equals(" ")){ b4.setText(s); b1.setText(" ");nodeBegin.moveUp();}
        nodeBegin.setChild(null);
    }//GEN-LAST:event_b1ActionPerformed

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
        String s=b2.getText();  
        if(b1.getText().equals(" ")){ b1.setText(s); b2.setText(" "); nodeBegin.moveRight();}  
        else if(b5.getText().equals(" ")){ b5.setText(s); b2.setText(" ");nodeBegin.moveUp();}
        nodeBegin.setChild(null);
    }//GEN-LAST:event_b2ActionPerformed

    private void b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b3ActionPerformed
        String s=b3.getText();  
        if(b4.getText().equals(" ")){ b4.setText(s); b3.setText(" "); nodeBegin.moveLeft();}  
        else if(b0.getText().equals(" ")){ b0.setText(s); b3.setText(" ");nodeBegin.moveDown();}
        else if(b6.getText().equals(" ")){ b6.setText(s); b3.setText(" "); nodeBegin.moveUp();}
        nodeBegin.setChild(null);
    }//GEN-LAST:event_b3ActionPerformed

    private void b4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b4ActionPerformed
        String s=b4.getText();  
        if(b1.getText().equals(" ")){ b1.setText(s); b4.setText(" "); nodeBegin.moveDown();}  
        else if(b3.getText().equals(" ")){ b3.setText(s); b4.setText(" ");nodeBegin.moveRight();}
        else if(b5.getText().equals(" ")){ b5.setText(s); b4.setText(" "); nodeBegin.moveLeft();}
        else if(b7.getText().equals(" ")){ b7.setText(s); b4.setText(" "); nodeBegin.moveUp();}
        nodeBegin.setChild(null);
    }//GEN-LAST:event_b4ActionPerformed

    private void b5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b5ActionPerformed
        String s=b5.getText();  
        if(b2.getText().equals(" ")){ b2.setText(s); b5.setText(" "); nodeBegin.moveDown();}  
        else if(b4.getText().equals(" ")){ b4.setText(s); b5.setText(" "); nodeBegin.moveRight();}
        else if(b8.getText().equals(" ")){ b8.setText(s); b5.setText(" "); nodeBegin.moveUp();}
        nodeBegin.setChild(null);
    }//GEN-LAST:event_b5ActionPerformed

    private void b6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b6ActionPerformed
        String s=b6.getText();  
        if(b3.getText().equals(" ")){ b3.setText(s); b6.setText(" "); nodeBegin.moveDown();}  
        else if(b7.getText().equals(" ")){ b7.setText(s); b6.setText(" "); nodeBegin.moveLeft();}
        nodeBegin.setChild(null);
    }//GEN-LAST:event_b6ActionPerformed

    private void b7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b7ActionPerformed
        String s=b7.getText();  
        if(b6.getText().equals(" ")){ b6.setText(s); b7.setText(" "); nodeBegin.moveRight();}  
        else if(b4.getText().equals(" ")){ b4.setText(s); b7.setText(" "); nodeBegin.moveDown();}
        else if(b8.getText().equals(" ")){ b8.setText(s); b7.setText(" "); nodeBegin.moveLeft();}
        nodeBegin.setChild(null);
    }//GEN-LAST:event_b7ActionPerformed

    private void b8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b8ActionPerformed
        String s=b8.getText();  
        if(b5.getText().equals(" ")){ b5.setText(s); b8.setText(" "); nodeBegin.moveDown();}  
        else if(b7.getText().equals(" ")){ b7.setText(s); b8.setText(" "); nodeBegin.moveRight();}
        nodeBegin.setChild(null);
    }//GEN-LAST:event_b8ActionPerformed
       
    private void runHeuristic1ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runHeuristic1ButtonActionPerformed
        viewTextArea.setText("");
        viewTextArea.append("Thuat toan A* (heuristic1)\n" +
                            "Chi so cap nguoc: " + nodeBegin.punish(statusEnd) + "\n");
        kq = aStar.runAStar(nodeBegin, nodeEnd, fringe, ls);
        aStar.result(kq);
        viewTextArea.append("So nut tao ra: " + aStar.soNutTaoRa + 
                            "\nSo nut phai xet: " + aStar.soNutPhaiXet +
                            "\nSo nut tren cay:" + aStar.soNutTrenCay +
                            "\nSo buoc dich chuyen f = " + kq.getF() +
                            "\nThoi gian chay ham A*: " + aStar.time + "ms");
        
    }//GEN-LAST:event_runHeuristic1ButtonActionPerformed

    private void runHeuristic0ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runHeuristic0ButtonActionPerformed
        viewTextArea.setText("");
        viewTextArea.append("Thuat toan A* (heuristic0)\n");
        kq = aStarH0.runAStar(nodeBegin, nodeEnd, fringe, ls);
        aStarH0.result(kq);
        viewTextArea.append("So nut tao ra: " + aStarH0.soNutTaoRa + 
                            "\nSo nut phai xet: " + aStarH0.soNutPhaiXet +
                            "\nSo nut tren cay:" + aStarH0.soNutTrenCay +
                            "\nSo buoc dich chuyen f = " + kq.getF() +
                            "\nThoi gian chay ham A*: " + aStarH0.time + "ms");
    }//GEN-LAST:event_runHeuristic0ButtonActionPerformed

    private void runHeuristic2ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runHeuristic2ButtonActionPerformed
        viewTextArea.setText("");
        viewTextArea.append("Thuat toan A* (heuristic0)\n");
        kq = aStarH2.runAStar(nodeBegin, nodeEnd, fringe, ls);
        aStarH2.result(kq);
        viewTextArea.append("So nut tao ra: " + aStarH2.soNutTaoRa + 
                            "\nSo nut phai xet: " + aStarH2.soNutPhaiXet +
                            "\nSo nut tren cay:" + aStarH2.soNutTrenCay +
                            "\nSo buoc dich chuyen f = " + kq.getF() +
                            "\nThoi gian chay ham A*: " + aStarH2.time + "ms");
    }//GEN-LAST:event_runHeuristic2ButtonActionPerformed
    
    private void viewStatus(Node N) {
        int i = N.indexBlank();
            if(0 == i)  b0.setText(" ");    else    b0.setText(Integer.toString(N.getStatus()[0]));    
            if(1 == i)  b1.setText(" ");    else    b1.setText(Integer.toString(N.getStatus()[1]));
            if(2 == i)  b2.setText(" ");    else    b2.setText(Integer.toString(N.getStatus()[2]));    
            if(3 == i)  b3.setText(" ");    else    b3.setText(Integer.toString(N.getStatus()[3]));    
            if(4 == i)  b4.setText(" ");    else    b4.setText(Integer.toString(N.getStatus()[4]));
            if(5 == i)  b5.setText(" ");    else    b5.setText(Integer.toString(N.getStatus()[5])); 
            if(6 == i)  b6.setText(" ");    else    b6.setText(Integer.toString(N.getStatus()[6]));   
            if(7 == i)  b7.setText(" ");    else    b7.setText(Integer.toString(N.getStatus()[7]));
            if(8 == i)  b8.setText(" ");    else    b8.setText(Integer.toString(N.getStatus()[8])); 
    }
    
    private void nextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButtonActionPerformed
        if(!Arrays.equals(nodeBegin.getStatus(), nodeEnd.getStatus())) {
            if(nodeBegin.getChild() == null)  // neu chua co loi giai thi chay A*  
                aStar.result(aStar.runAStar(nodeBegin, nodeEnd, fringe, ls));
            // chuyen trang thai cua nodeBegin
            nodeBegin = nodeBegin.getChild();
            nodeBegin.setParent(null);
            viewStatus(nodeBegin);
            if(Arrays.equals(nodeBegin.getStatus(), nodeEnd.getStatus()))
            JOptionPane.showMessageDialog(rootPane, "DONE!");
        }
    }//GEN-LAST:event_nextButtonActionPerformed

    Control ctrl;
    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        ctrl.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_exitButtonActionPerformed

    private void newButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newButtonActionPerformed
        //nodeBegin.setStatus(statusBegin);
        nodeBegin.randomStatus();
        nodeBegin.setChild(null);   // chua co loi giai
        viewStatus(nodeBegin);
    }//GEN-LAST:event_newButtonActionPerformed

    private void runHeuristic4ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runHeuristic4ButtonActionPerformed
        viewTextArea.setText("");
        viewTextArea.append("Thuat toan A* (heuristic4)\n");
        kq = aStarH4.runAStar(nodeBegin, nodeEnd, fringe, ls);
        aStarH4.result(kq);
        viewTextArea.append("So nut tao ra: " + aStarH4.soNutTaoRa + 
                            "\nSo nut phai xet: " + aStarH4.soNutPhaiXet +
                            "\nSo nut tren cay:" + aStarH4.soNutTrenCay +
                            "\nSo buoc dich chuyen f = " + kq.getF() +
                            "\nThoi gian chay ham A*: " + aStarH4.time + "ms");
    }//GEN-LAST:event_runHeuristic4ButtonActionPerformed

    private void runHeuristic3ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runHeuristic3ButtonActionPerformed
        viewTextArea.setText("");
        viewTextArea.append("Thuat toan A* (heuristic3)\n");
        kq = aStarH3.runAStar(nodeBegin, nodeEnd, fringe, ls);
        aStarH3.result(kq);
        viewTextArea.append("So nut tao ra: " + aStarH3.soNutTaoRa + 
                            "\nSo nut phai xet: " + aStarH3.soNutPhaiXet +
                            "\nSo nut tren cay:" + aStarH3.soNutTrenCay +
                            "\nSo buoc dich chuyen f = " + kq.getF() +
                            "\nThoi gian chay ham A*: " + aStarH3.time + "ms");
    }//GEN-LAST:event_runHeuristic3ButtonActionPerformed
    
        static Node nodeBegin = new Node(9);
        static Node nodeEnd = new Node(9);
        static int statusBegin[] = {0,2,1,6,7,5,3,8,4};
        static int statusEnd[] = {0,1,2,3,4,5,6,7,8};
        static Fringe fringe = new Fringe();
        static ListStatus ls = new ListStatus(9);       
        static AStarH1 aStar = new AStarH1();
        static AStarH0 aStarH0 = new AStarH0();
        static AStarH2 aStarH2 = new AStarH2();
        static AStarH3 aStarH3 = new AStarH3();
        static AStarH4 aStarH4 = new AStarH4();
        static Node kq;
    
    //public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        /*try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Puzzle3x3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Puzzle3x3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Puzzle3x3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Puzzle3x3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }*/
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        /*nodeBegin.setStatus(statusBegin);
        nodeEnd.setStatus(statusEnd);
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Puzzle3x3().setVisible(true);
            }
        });
    }*/

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b0;
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JButton b3;
    private javax.swing.JButton b4;
    private javax.swing.JButton b5;
    private javax.swing.JButton b6;
    private javax.swing.JButton b7;
    private javax.swing.JButton b8;
    private javax.swing.JLabel currentStatusLabel;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel goalStatusLabel;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton newButton;
    private javax.swing.JButton nextButton;
    private javax.swing.JButton runHeuristic0Button;
    private javax.swing.JButton runHeuristic1Button;
    private javax.swing.JButton runHeuristic2Button;
    private javax.swing.JButton runHeuristic3Button;
    private javax.swing.JButton runHeuristic4Button;
    private javax.swing.JTextArea viewTextArea;
    // End of variables declaration//GEN-END:variables
}
