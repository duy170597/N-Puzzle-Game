/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package puzzlegameview;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author duy
 */
public class Node {
    private int n;
    private int[] status;
    private int f; // f(n) = g(n) + h(n)
    private int g;
    private int h;
    private Node parent;
    private Node child;
     int sqrtN;
    
    public Node(int n) {
        this.n = n;
        sqrtN = (int) Math.sqrt((double)n);
        status  = new int[n];
        f = 0;
        g = 0;
        h = 0;
        parent = null;
        child = null;
        Arrays.fill(status, 0);
    }
    public int getF() {
        return f;
    }
    public void setF(int f) {
        this.f = f;
    }
    public int getG() {
        return g;
    }
    public void setG(int g) {
        this.g = g;
    }
    public int getH() {
        return h;
    }
    public void setH(int h) {
        this.h = h;
    }
    public void setParent(Node parent) {
        this.parent = parent;
    }
    public Node getParent() {
        return parent;
    }
    public void setChild(Node child) {
        this.child = child;
    }
    public Node getChild() {
        return child;
    }
    public void setStatus(int status[]) {
        int i;
        for(i = 0; i < n; i++) {
            this.status[i] = status[i];
        }
    }
    public int[] getStatus() {
        return status;
    }
    
    
    public void printStatus() {
        for(int i = 0; i < n; i++) {
            if(status[i] != 0) {
                System.out.printf("%d ", status[i]);
                if((i%sqrtN) == (sqrtN-1))  System.out.println();
            }
            else {
                System.out.printf("  ", status[i]);
                if((i%sqrtN) == (sqrtN-1))  System.out.println();
            }
        }
        System.out.println("--------------\n");
    }
    public int indexBlank() {   // Tim vi tri o trong
        int i;
        for(i = 0; i < n; i++) {
           if(status[i] == 0)    break;
        }
        return i;
    }
    // di chuyen o trong len tren
    public boolean moveUp() {
        // Tim kiem o trong
        int i = this.indexBlank();
        if((i/sqrtN) != 0) {
            status[i] = status[i-sqrtN];
            status[i-sqrtN] = 0;
            return true;
        }
        return false;
    }
    public boolean moveDown() {
        // Tim kiem o trong
        int i = this.indexBlank();
        if((i/sqrtN) != (sqrtN-1)) {
            status[i] = status[i+sqrtN];
            status[i+sqrtN] = 0;
            return true;
        }
        return false;
    }
    public boolean moveLeft() {
        // Tim kiem o trong
        int i = this.indexBlank();
        if((i%sqrtN) != 0) {
            status[i] = status[i-1];
            status[i-1] = 0;
            return true;
        }
        return false;
    }
    public boolean moveRight() {
        // Tim kiem o trong
        int i = this.indexBlank();
        if((i%sqrtN) != (sqrtN-1)) {
            status[i] = status[i+1];
            status[i+1] = 0;
            return true;
        }
        return false;
    }
    
    public int heuristic1(int[] statusEnd) {
        // h1(n) = khoang cach dich chuyen len xuong phai trai ngan nhat 
        // de dich chuyen cac o chu nam sai vi tri ve vi tri dung
        int i, j, heuristic1 = 0;
        int k = this.indexBlank();
        for(i = 0; i < n; i++) {
            if(i != k) {
                for(j = 0; j < n; j++) {
                if(status[i] == statusEnd[j]) { // tim vi tri status[i] o StatusEnd
                    heuristic1 += Math.abs((i/sqrtN)-(j/sqrtN)) + Math.abs((i%sqrtN)-(j%sqrtN));
                }
            }
            }
        }
        return heuristic1;
    }
    
    public int heuristic0(int[] statusEnd) {
        // so cac o chu nam o sai vi tri
        int i, heuristic0 = 0;
        int k = this.indexBlank();
        for(i = 0; i < n; i++) {
            if(i != k) {
                if(status[i] != statusEnd[i])   heuristic0++;
            }
        }
        return heuristic0;
    }
    
    // Ham tinh chi so phat cap o hang xom dang nam nguoc vi tri
    public int punish(int[] statusEnd) {
        int a = 0;
        for(int i = 0; i < n; i++) {
            if((status[i] != 0) ) {
                if(((i%sqrtN) < (sqrtN-1)) && (status[i+1] != 0)) {
                    if((status[i] == statusEnd[i+1]) && (status[i+1] == statusEnd[i]))
                        a = a +2;
                }
                if(((i/sqrtN) < (sqrtN-1)) && (status[i+sqrtN] != 0)) {
                    if((status[i] == statusEnd[i+sqrtN]) && (status[i+sqrtN] == statusEnd[i])) 
                        a = a + 2;
                }
            }
        }
        return a;
    }
    
    public int heuristic2(int[] statusEnd) {
        return (heuristic1(statusEnd) + punish(statusEnd));
    }
    
    public int space(int[] statusEnd) {
        // d = |row s – row đ|^2 + |col s – col đ|^ 2
        int i, j, d = 0;
        int k = this.indexBlank();
        for(i = 0; i < n; i++) {
            if(i != k) {
                for(j = 0; j < n; j++) {
                if(status[i] == statusEnd[j]) { // tim vi tri status[i] o StatusEnd
                    d += (int) (Math.pow(Math.abs((i/sqrtN)-(j/sqrtN)), 2) + Math.pow(Math.abs((i%sqrtN)-(j%sqrtN)), 2));
                }
            }
            }
        }
        return d;
    }
    
    public int heuristic3(int[] statusEnd) {
        // d = |row s – row đ|^2 + |col s – col đ^ 2
        // h3 = d3 – [0.15*d3 ] + a
        int d3 = space(statusEnd);
        return (d3 - (int)(0.15 * d3) + punish(statusEnd));
    }
    
    public int heuristic4(int[] statusEnd) {
        //h4 = d4 + a
        return (space(statusEnd) + punish(statusEnd));
    }
    
    // tao mot stastu random
    public void randomStatus() {
        Random rd = new Random();
        int moveTimes = 30 + rd.nextInt(20);   // moveTimes - so lan dich chuyen o trong
        int moveDirection;
        
        for(int i = 0; i < moveTimes; i++) {
            moveDirection = rd.nextInt(4);
            if(moveDirection == 0)  this.moveDown();
            else if(moveDirection == 1) this.moveLeft();
            else if(moveDirection == 2) this.moveRight();
            else if(moveDirection == 3) this.moveUp();
        }
    }
}
