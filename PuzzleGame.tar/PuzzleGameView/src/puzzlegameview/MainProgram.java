/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package puzzlegameview;

public class MainProgram {
    static Control ctrl;
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainProgram.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainProgram.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainProgram.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainProgram.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ctrl = new Control();
                ctrl.setVisible(true);
            }
        });
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ctrl.p3 = new Puzzle3x3();
                ctrl.p3.setVisible(false);
                ctrl.p3.ctrl = ctrl;
            }
        });
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ctrl.p4 = new Puzzle4x4();
                ctrl.p4.setVisible(false);
                ctrl.p4.ctrl = ctrl;
            }
        });
        
        Node nodeBegin = new Node(16);
        Node nodeEnd = new Node(16);
        int statusBegin[] = {4,1,5,2,15,14,7,0,10,8,6,3,9,12,13,11};
        int statusEnd[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
        nodeBegin.setStatus(statusBegin);
        nodeBegin.moveDown();
        //nodeBegin.moveDown();
        //nodeBegin.moveLeft();
        //System.out.println(nodeBegin.heuristic3(statusEnd));
        
        
        
    }
}
